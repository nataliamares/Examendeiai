#include <iostream>

int main()
{
	int day;
	int MoNth;
	int year;
	int nextday;
	int monthnext;
	int nextyear;

	scanf_s("%i", &day);

	scanf_s("%i", &MoNth);

	scanf_s("%i", &year);
	{

		if ((day == 28 && MoNth == 2) || (day == 30 && (MoNth == 4 || MoNth == 6 || MoNth == 9 || MoNth == 11)) || day == 31) nextday = 1;
		else
			nextday = day + 1;
		if (nextday == 1)
			monthnext = MoNth + 1;
		else
			monthnext = MoNth;
		if (monthnext == 13)
			nextyear = year + 1;
		else
			nextyear = year;
		if (monthnext == 13)
			monthnext = 1;
	}
	if (year == 400 || year == 800 || year == 1200 || year == 1600 || year == 2000 || year == 2400 || year == 2800)
	{
		if (day == 28 && MoNth == 2)
		{
			nextday = day + 1;
			monthnext = MoNth;
		}
		if (day == 29 && MoNth == 2)
		{
			nextday = 1;
			monthnext = MoNth + 1;
		}
	}


	printf("%2.0i %2.0i %4.0i", nextday, monthnext, nextyear);

	return 0;
}